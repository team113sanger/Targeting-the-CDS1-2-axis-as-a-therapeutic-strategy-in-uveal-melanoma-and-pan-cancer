library(tidyverse)
library(ggplot2)
library(tidylog)

###########

# Load expression data and process
exp <- read.table(file.path('./mRNA Expression, RSEM (Batch normalized from Illumina HiSeq_RNASeqV2).txt'), sep = '\t', header = TRUE) %>% 
  as_tibble() %>% 
  mutate(STUDY_ID = toupper(sub("_.*", "", STUDY_ID))) %>% 
  pivot_longer(CDS1:MDM4, names_to = 'gene', values_to = 'tpm') %>% 
  mutate(log_tpm_plus_one = log2(tpm + 1)) %>% 
  pivot_wider(names_from = gene, values_from = tpm:log_tpm_plus_one)
  
# Write out data file
write.csv(exp, './uvm_expression_data_processed.csv')
